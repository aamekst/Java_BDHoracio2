package br.com.horacio2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.horacio2.beans.Pessoa;

public class PessoaDAO {

	private Connection con;

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
	public String inserir(Pessoa pessoa)
	{
		String sql = "Insert into pessoa(nome, endereco) VALUES(?,?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, pessoa.getNome());
			ps.setString(2, pessoa.getEndereco());
			
			if(ps.executeUpdate() > 0)
				return "Inserido com sucesso!!";
			else
				return "Erro ao inserir"; 
				
		} catch (SQLException e) {
			return e.getMessage();
		}
	}
}
