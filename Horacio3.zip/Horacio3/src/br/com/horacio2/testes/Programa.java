package br.com.horacio2.testes;

import br.com.horacio2.beans.Pessoa;

public class Programa {

	public static void main(String[] args)
	{
		Pessoa pessoa = new Pessoa("Gabriel", "Água Fria");
		
	}
}
