package br.com.horacio2.testes;

import java.sql.Connection;

import br.com.horacio2.beans.Pessoa;
import br.com.horacio2.conexao.ConexaoDAO;
import br.com.horacio2.dao.PessoaDAO;

public class ProgramaDeletar {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Connection con = ConexaoDAO.abrirConexao();
		
		
		PessoaDAO pessoadao = new PessoaDAO(con);

		System.out.println(pessoadao.Deleter(null));
	}

}
