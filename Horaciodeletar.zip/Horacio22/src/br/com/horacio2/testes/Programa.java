package br.com.horacio2.testes;

import java.sql.Connection;

import br.com.horacio2.beans.Pessoa;

import br.com.horacio2.conexao.ConexaoDAO;
import br.com.horacio2.dao.PessoaDAO;

public class Programa {

	public static void main(String[] args) throws Exception
	{
		Connection con = ConexaoDAO.abrirConexao();
		
		Pessoa pessoa = new Pessoa("Alana", "Rua papai");
		
		PessoaDAO pessoadao = new PessoaDAO(con);

		System.out.println(pessoadao.inserir(pessoa));
	}
}
