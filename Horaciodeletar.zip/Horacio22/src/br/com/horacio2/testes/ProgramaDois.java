package br.com.horacio2.testes;

public class ProgramaDois {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
